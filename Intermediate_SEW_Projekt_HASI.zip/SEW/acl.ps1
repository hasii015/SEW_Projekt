netsh http add urlacl url=http://+:12000/ user=$env:USERNAME
